﻿*************************************************************
*                                                           *
*             Therefore™ SDK Version 2.0                    *
*															*
*             COPYRIGHT ® 2015 Therefore Corporation.       *
*             All rights reserved.                          *
*                                                           *
*************************************************************
Sample:
WFExtractFiles

Description:
This sample shows how to create a Workflow DLL that can be integrated into a workflow process.
If you want to debug this sample use the "Attach to Process..." [Ctrl+Alt+P] to attach to the 
TheServer process. 

Requirements:
* You will a need a valid workflow for this sample.

Build-Steps:
* Depending on your installed Therefore version you will either need the ProcAutomaticInst() 
  method with one or with two parameters.